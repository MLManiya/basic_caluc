package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        Button button1,button2,buttonadd;
        EditText editText1,editText2;
        TextView Ans;
        String temp1,temp2;
        int n1,n2;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            editText1 = findViewById(R.id.editText1);
            editText2 = findViewById(R.id.editText2);
            Ans = findViewById(R.id.Ans);
            button1 = findViewById(R.id.button1);
            button2 = findViewById(R.id.button2);
            buttonadd = findViewById(R.id.buttonadd);

            editText1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    String str1 = charSequence.toString();
                    String str2 = editText2.getText().toString();

                    if(str2.length()<=10) {
                        System.out.println("Hello ");

                        if (str2.isEmpty()) {
                            n2 = 0;
                            editText2.setError("Field Not Empty");
                        } else {
                            n2 = Integer.parseInt(editText2.getText().toString());
                        }
                        if (str1.isEmpty()) {
                            n1 = 0;
                        } else {
                            n1 = Integer.parseInt(editText1.getText().toString());
                        }
                    }
                    int sum = n1+n2;
                    Ans.setText(""+sum);
                    button2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if(str1.length()>0)
                            {
                                temp1 = str1.substring(0,str1.length()-1);
                                editText1.setText(temp1);
                            }
                            else
                            {
                                editText1.setText("");
                            }
                        }
                    });
                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });
        }
}

